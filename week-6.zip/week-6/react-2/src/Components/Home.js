import React, { Component } from 'react';

class Home extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <h2>Welcome to the Home page of Student Management Portal</h2>;
  }
}

export default Home;